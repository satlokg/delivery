<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }
    public function mal_mukadmati()
    {
        return view('mal_mukadmati');
    }
    public function mal_lawarish()
    {
        return view('mal_lawarish');
    }
    public function mal_kurki()
    {
        return view('mal_kurki');
    }
    public function anya_mal()
    {
        return view('anya_mal');
    }
    public function vahan_srhiti()
    {
        return view('vahan_srhiti');
    }
    public function mvact()
    {
        return view('mvact');
    }
}
